<?php
// --------------------
// Database connection
// --------------------
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'blog_app'; // make sure this database exists

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die('DB error: ' . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

// --------------------
// Safer cookies + session
// --------------------
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// --------------------
// Small helper function
// --------------------
if (!function_exists('e')) {
    function e($s) {
        return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    }
}

// --------------------
// CSRF helpers
// --------------------
if (!function_exists('csrf_token')) {
    function csrf_token() {
        if (empty($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf'];
    }
}

if (!function_exists('csrf_check')) {
    function csrf_check() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (empty($_POST['csrf']) || !hash_equals($_SESSION['csrf'], $_POST['csrf'])) {
                http_response_code(419);
                exit('CSRF check failed');
            }
        }
    }
}

// --------------------
// Auth helpers
// --------------------
if (!function_exists('requireLogin')) {
    function requireLogin() {
        if (empty($_SESSION['user_id'])) {
            header('Location: login.php');
            exit;
        }
    }
}

if (!function_exists('requireRole')) {
    function requireRole($roles) {
        requireLogin();
        $roles = (array)$roles;
        if (!in_array($_SESSION['role'] ?? 'user', $roles)) {
            http_response_code(403);
            exit('Forbidden');
        }
    }
}
?>
