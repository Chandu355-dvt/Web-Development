<?php
require 'db.php';
requireRole(['admin','editor']); // only these roles can add

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $title = trim($_POST['title']);
  $content = trim($_POST['content']);
  $errors = [];
  if($title==='' || mb_strlen($title)>255){ $errors[]="Title is required (max 255)."; }
  if($content===''){ $errors[]="Content is required."; }

  if(!$errors){
    $stmt = $conn->prepare("INSERT INTO posts (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);
    if($stmt->execute()){ header('Location: index.php'); exit; }
    $errors[] = "DB error: ".$conn->error;
    $stmt->close();
  }
}
?>
<!doctype html>
<html>
<head><title>Add Post</title></head>
<body>
<h2>Add Post</h2>
<?php if(!empty($errors)) foreach($errors as $e) echo "<p style='color:red'>".e($e)."</p>"; ?>
<form method="post">
  <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
  <label>Title</label><br>
  <input name="title" required maxlength="255"><br><br>
  <label>Content</label><br>
  <textarea name="content" required rows="6" cols="50"></textarea><br><br>
  <button type="submit">Save</button>
</form>
<a href="index.php">Back</a>
</body>
</html>
