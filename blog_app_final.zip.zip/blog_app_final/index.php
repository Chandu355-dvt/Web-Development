<?php
// Show errors while debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once "db.php"; // include your database connection

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Fetch posts from database
$sql = "SELECT id, title, content, created_at FROM posts ORDER BY created_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Blog Homepage</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f2f2f2;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 15px;
            border-radius: 5px;
        }
        .header a {
            color: yellow;
            text-decoration: none;
            margin-left: 15px;
        }
        .post {
            background: white;
            margin: 15px 0;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 5px gray;
        }
        .post h2 {
            margin: 0;
            color: #2c3e50;
        }
        .post p {
            color: #333;
        }
    </style>
</head>
<body>

<div class="header">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?> 🎉</h1>
    <a href="logout.php">Logout</a>
    <?php if ($_SESSION['role'] === 'admin'): ?>
        <a href="create_post.php">➕ Create Post</a>
    <?php endif; ?>
</div>

<h2>Latest Posts</h2>

<?php
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='post'>";
        echo "<h2>" . htmlspecialchars($row['title']) . "</h2>";
        echo "<p>" . nl2br(htmlspecialchars($row['content'])) . "</p>";
        echo "<small>Posted on " . $row['created_at'] . "</small>";
        echo "</div>";
    }
} else {
    echo "<p>No posts yet. Be the first to write!</p>";
}
?>

</body>
</html>
