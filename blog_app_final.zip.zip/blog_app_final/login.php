<?php
session_start();
include 'db.php';

require 'db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $username = trim($_POST['username']);
  $password = $_POST['password'];

  $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username=?");
  $stmt->bind_param("s", $username);
  $stmt->execute();
  $stmt->bind_result($id, $hash, $role);

  if($stmt->fetch() && password_verify($password, $hash)){
    session_regenerate_id(true);
    $_SESSION['user_id']=$id;
    $_SESSION['username']=$username;
    $_SESSION['role']=$role;
    header('Location: index.php'); exit;
  } else { $error="Invalid credentials"; }
  $stmt->close();
}
?>
<!doctype html>
<html>
<head><title>Login</title></head>
<body>
<h2>Login</h2>
<?php if(!empty($error)) echo "<p style='color:red'>".e($error)."</p>"; ?>
<form method="post">
  <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
  <label>Username</label><br>
  <input name="username" required minlength="3" maxlength="100"><br><br>
  <label>Password</label><br>
  <input type="password" name="password" required minlength="6"><br><br>
  <button type="submit">Login</button>
</form>
<a href="register.php">Register</a>

</body>
</html>

