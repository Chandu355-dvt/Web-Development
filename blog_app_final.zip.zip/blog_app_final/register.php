<?php
require 'db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $username = trim($_POST['username']);
  $password = $_POST['password'];
  $errors = [];

  // basic server-side checks
  if($username==='' || strlen($username)<3){ $errors[]="Username too short"; }
  if(strlen($password)<6){ $errors[]="Password must be at least 6 characters"; }

  if(!$errors){
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'user')");
   

    $stmt->bind_param("ss", $username, $hash);
    if($stmt->execute()){ header('Location: login.php'); exit; }
    $errors[] = "Username already taken";
    $stmt->close();
  }
}
?>
<!doctype html>
<html>
<head><title>Register</title></head>
<body>
<h2>Register</h2>
<?php if(!empty($errors)) foreach($errors as $e) echo "<p style='color:red'>".e($e)."</p>"; ?>
<form method="post">
  <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
  <label>Username</label><br>
  <input name="username" required minlength="3" maxlength="100" pattern="[A-Za-z0-9_]+"><br><br>
  <label>Password</label><br>
  <input type="password" name="password" required minlength="6"><br><br>
  <button type="submit">Create account</button>
</form>
<a href="login.php">Back to login</a>
<input required minlength="3" maxlength="255">
<textarea required></textarea>

</body>
</html>
