# Blog Application (Final Project)

## How to Run
1. Copy `blog_app_final` folder into `C:\xampp\htdocs\`.
2. Start Apache & MySQL from XAMPP.
3. Open `http://localhost/blog_app_final/` in your browser.
4. Import `sql/schema.sql` into phpMyAdmin to create tables.
5. Update `db.php` with your database username/password.

## Features
- Register & login
- Roles (Admin / User)
- Create, edit, delete posts
- Search & pagination
- Secure: prepared statements, password hashing, CSRF, validation
