# Security Measures

- Prepared statements for all queries (to prevent SQL Injection).
- Passwords hashed using `password_hash` and checked with `password_verify`.
- Server-side form validation on all inputs.
- CSRF tokens for all POST requests.
- Escaping user input with `htmlspecialchars()` to prevent XSS.
- Role-based access control (Admin vs User).
- Secure session handling.
