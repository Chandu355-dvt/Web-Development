<?php
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

echo "<h2>Welcome, " . $_SESSION['username'] . "!</h2>";
echo "<a href='create_post.php'>Create New Post</a> | ";
echo "<a href='logout.php'>Logout</a><hr>";

$result = $conn->query("SELECT * FROM posts ORDER BY created_at DESC");

while ($row = $result->fetch_assoc()) {
    echo "<h3>" . htmlspecialchars($row['title']) . "</h3>";
    echo "<p>" . htmlspecialchars($row['content']) . "</p>";
    echo "<a href='edit_post.php?id=" . $row['id'] . "'>Edit</a> | ";
    echo "<a href='delete_post.php?id=" . $row['id'] . "' onclick=\"return confirm('Delete this post?');\">Delete</a>";
    echo "<hr>";
}
?>