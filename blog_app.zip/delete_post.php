<?php
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$id = intval($_GET['id']);
$conn->query("DELETE FROM posts WHERE id=$id");

header("Location: index.php");
exit;
?>