<?php
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$id = intval($_GET['id']);
$result = $conn->query("SELECT * FROM posts WHERE id=$id");
$post = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);
    $sql = "UPDATE posts SET title='$title', content='$content' WHERE id=$id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    }
}
?>
<form method="post">
    <h2>Edit Post</h2>
    <input type="text" name="title" value="<?= htmlspecialchars($post['title']); ?>" required><br>
    <textarea name="content" required><?= htmlspecialchars($post['content']); ?></textarea><br>
    <button type="submit">Update</button>
</form>