<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

$search = isset($_GET['search']) ? $_GET['search'] : "";
$where = $search ? "WHERE title LIKE '%$search%' OR content LIKE '%$search%'" : "";

$result = $conn->query("SELECT COUNT(*) as total FROM posts $where");
$total = $result->fetch_assoc()['total'];
$pages = ceil($total / $limit);

$sql = "SELECT * FROM posts $where ORDER BY created_at DESC LIMIT $start, $limit";
$posts = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Blog Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Welcome to Blog</h2>
    <form method="get">
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search posts">
        <button type="submit">Search</button>
    </form>
    <a href="logout.php">Logout</a>
    <hr>
    <?php while($row = $posts->fetch_assoc()): ?>
        <h3><?php echo $row['title']; ?></h3>
        <p><?php echo substr($row['content'], 0, 200); ?>...</p>
        <small><?php echo $row['created_at']; ?></small>
        <hr>
    <?php endwhile; ?>

    <nav>
        <?php for($i = 1; $i <= $pages; $i++): ?>
            <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
        <?php endfor; ?>
    </nav>
</div>
</body>
</html>
